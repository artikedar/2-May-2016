package org.capstore.controller;

import java.security.Provider.Service;
import java.util.Map;

import org.capstore.dao.CustomerDaoInterface;
import org.capstore.pojo.Product;
import org.capstore.service.CustomerServiceImpl;
import org.capstore.service.CustomerServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

	@Autowired
	CustomerServiceImpl service;
	
	@Autowired
	CustomerDaoInterface dao;
	
	@RequestMapping("/hello")
	public ModelAndView sayHello(){
		String message="Hello Spring MVC";
		service.search();

		return service.search();
	}
	
	
}
