package org.capstore.service;

import java.util.List;

import org.capstore.dao.CustomerDaoImpl;
import org.capstore.dao.CustomerDaoInterface;
import org.capstore.pojo.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;

public class CustomerServiceImpl implements CustomerServiceInterface {

	
	@Autowired
	CustomerDaoImpl dao;
	
	@Override
	public ModelAndView search() {
	
		return dao.searchCustomer();
		
	}

	@Override
	public List<Product> getAllProducts() {
		
		return dao.getAllProducts();
	}
	
}
