package org.capstore.pojo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Category {
	@Id
	@GeneratedValue
	private int category_id;
	private String cateogry_name;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY,
			targetEntity=Product.class,mappedBy="category")
	List<Product> products=new ArrayList<>();
	public Category(){}
	
	
	public Category(int category_id, String cateogry_name) {
		super();
		this.category_id = category_id;
		this.cateogry_name = cateogry_name;
	}


	public int getCategory_id() {
		return category_id;
	}


	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}


	public String getCateogry_name() {
		return cateogry_name;
	}


	public void setCateogry_name(String cateogry_name) {
		this.cateogry_name = cateogry_name;
	}


	@Override
	public String toString() {
		return "Category [category_id=" + category_id + ", cateogry_name=" + cateogry_name + "]";
	}
	
	
	
	
	

}
