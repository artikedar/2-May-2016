package org.capstore.dao;

import java.util.ArrayList;
import java.util.List;

import org.capstore.pojo.Product;
import org.capstore.service.CustomerServiceInterface;
import org.hibernate.SessionFactory;
import org.omg.CORBA.PUBLIC_MEMBER;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

public class CustomerDaoImpl  implements CustomerDaoInterface{

	@Autowired
	private SessionFactory sessionFactory;

	
	@Override
	@RequestMapping("/hello")
	public ModelAndView searchCustomer() {
		System.out.println("Hello Customer");
		String message="Hello Customer";
		return new ModelAndView("helloPage","msg2",message);
	}
	

	@Override
	public List<Product> getAllProducts() {
		
		List<Product> productList=new ArrayList<>();
		
		productList=sessionFactory.getCurrentSession().createQuery("from Product").list();
		
		System.out.println("List got from DB is"+productList.size());
		
		
		return productList;
	}
	
	

}
